name = "Checkbox"
description = """Checkbox allows to select one or more items from a group, or switch between two mutually exclusive options (checked or unchecked, on or off)."""
image_file = "text.svg"