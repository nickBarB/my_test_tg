name = "Chip"
description = """Chips are compact elements that represent an attribute, text, entity, or action."""
