name = "Control colors"
description = """Examples of controls color properties defined on different levels."""