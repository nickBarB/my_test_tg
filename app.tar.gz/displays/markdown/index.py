name = "Markdown"
description = """Control for rendering text in markdown format."""
image_file = "markdown.svg"