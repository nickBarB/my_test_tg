name = "Text"
description = """Text is a control for displaying text."""
image_file = "text.svg"