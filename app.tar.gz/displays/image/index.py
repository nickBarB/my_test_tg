name = "Image"
description = """An image is a graphic representation of something (e.g photo or illustration)."""
image_file = "image.svg"