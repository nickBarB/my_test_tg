name = "DataTable"
description = """A Material Design data table."""
image_file = "datatable.svg"