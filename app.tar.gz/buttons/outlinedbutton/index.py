name = "OutlinedButton"
description = """Outlined buttons are medium-emphasis buttons. They contain actions that are important, but aren’t the primary action in an app. Outlined buttons pair well with filled buttons to indicate an alternative, secondary action."""
image_file = "outlinedbutton.svg"