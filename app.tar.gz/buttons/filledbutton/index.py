name = "FilledButton"
description = """Filled buttons have the most visual impact after the FloatingActionButton, and should be used for important, final actions that complete a flow, like Save, Join now, or Confirm."""
image_file = "filledbutton.svg"