name = "FilePicker"

description = """A control that allows you to use the native file explorer to pick single or multiple files, with extensions filtering support and upload."""

image_file = "appbar.svg"