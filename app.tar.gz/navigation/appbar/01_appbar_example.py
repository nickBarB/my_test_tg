import flet as ft

name = "AppBar Example"

def example():
    
    return ft.Text("This example is under construction")