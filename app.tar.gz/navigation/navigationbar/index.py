name = "NavigationBar"

description = """Material 3 Navigation Bar component.

Navigation bars offer a persistent and convenient way to switch between primary destinations in an app."""

image_file = "navigationbar.svg"